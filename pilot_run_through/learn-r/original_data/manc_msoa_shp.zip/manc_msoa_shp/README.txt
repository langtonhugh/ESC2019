Files:
england_msoa_2011.shp
england_msoa_2011.shx
england_msoa_2011.dbf
england_msoa_2011.prj

Areas:
Manchester

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.